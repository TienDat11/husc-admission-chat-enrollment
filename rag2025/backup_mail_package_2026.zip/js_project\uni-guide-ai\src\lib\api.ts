/**
 * API Service for RAG Backend
 *
 * Connects to FastAPI backend running on port 8000
 * Endpoints:
 * - POST /query - Main RAG query endpoint
 * - GET /health - Health check
 */

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

export interface QueryRequest {
  query: string;
  force_rag_only?: boolean;
}

export interface QueryResponse {
  original_query: string;
  enhanced_query: string;
  query_type: string;
  answer: string;
  sources: string[];
  confidence: number;
  top_k_used: number;
  chunks_used: number;
  provider: string;
  status_code?: string;
  status_reason?: string;
  data_gap_hints?: string[];
  internal_status_code?: string | null;
  chunks?: any[];
}

export interface HealthResponse {
  status: string;
  lancedb_connected: boolean;
  vectors_count: number;
  collection: string;
  embedding_model: string;
  reranker_model: string;
}

/**
 * Send a chat message to the RAG backend
 */
export async function sendChatMessage(query: string, forceRagOnly = false): Promise<QueryResponse> {
  try {
    const response = await fetch(`${API_BASE_URL}/query`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        query,
        force_rag_only: forceRagOnly,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(
        errorData.detail || `API error: ${response.status} ${response.statusText}`
      );
    }

    const data: QueryResponse = await response.json();
    return data;
  } catch (error) {
    console.error('Failed to send chat message:', error);
    throw error;
  }
}

/**
 * Check backend health status
 */
export async function checkHealth(): Promise<HealthResponse> {
  try {
    const response = await fetch(`${API_BASE_URL}/health`);

    if (!response.ok) {
      throw new Error(`Health check failed: ${response.status} ${response.statusText}`);
    }

    const data: HealthResponse = await response.json();
    return data;
  } catch (error) {
    console.error('Failed to check health:', error);
    throw error;
  }
}

/**
 * Get API base URL
 */
export function getApiBaseUrl(): string {
  return API_BASE_URL;
}
